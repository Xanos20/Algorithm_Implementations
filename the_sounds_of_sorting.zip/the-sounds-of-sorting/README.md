# CSC 207 (Fall 2016) Homework: The Sounds of Sorting

[The Sounds of Sorting](http://www.cs.grinnell.edu/~osera/courses/csc207/17sp/homeworks/the-sounds-of-sorting.html)




Resources:
